package com.oraclejava;

public class BmiForm {

	private double height;
	private int weight;
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "BmiForm [height=" + height + ", weight=" + weight + "]";
	}
	
//	계산식
//	public void calc() {
//		double bmi;
//		double m_height = height * 0.01; // cm -> m
//		bmi = weight / (m_height *m_height);
//		System.out.println("BMI = " + bmi);
//	}
	
}
