package com.oraclejava;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	//람다식 표현 다시 한번 살펴볼것 jdbcTemplate의 람다식 표현 
	public List<Customer> findAll() {
		String sql = "select id,firstname,lastname" + " from customer";
		//람다식 표현
		List<Customer> result = 
				jdbcTemplate.query(sql, (rs, rowNum) -> 
				new Customer(rs.getInt("id"),
						rs.getString("firstname"),
						rs.getString("lastname"))
				); //람다식 표현 봐보기
		return result;
	}
}
