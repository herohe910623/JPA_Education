package com.oraclejava;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/bmiForm")
public class BmiController {

	@GetMapping
	public String show(Model model) {
		model.addAttribute("bmiForm",new BmiForm());
		return "bmiForm";
	}
	
//	BMI 계산식
//	public void calc() {
//		double bmi;
//		double m_height = height * 0.01; // cm -> m
//		bmi = weight / (m_height *m_height);
//		System.out.println("BMI = " + bmi);
//	}
	
	@PostMapping
	public String showSubmit(BmiForm bmiForm,Model model) {
		System.out.println("키는 = " +bmiForm.getHeight()+"몸무게는 = "+ bmiForm.getWeight());
		model.addAttribute("height", bmiForm.getHeight());
		model.addAttribute("weight", bmiForm.getWeight());
		
		double bmiHeight = bmiForm.getHeight();
		int bmiWeight = bmiForm.getWeight();
		double m_bmiHeight = bmiHeight * 0.01 ;
		double bmi = bmiWeight / (m_bmiHeight * m_bmiHeight);
		
		model.addAttribute("bmi",bmi);
		
		
		return "bmiFormSubmit"; 
			
	}
}
