package com.oraclejava;

public class MyForm {

	private String name; //이름
	private int age; //나이

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "MyForm [name=" + name + ", age=" + age + "]";
	}
	
	
}
