package com.oraclejava;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

	@RequestMapping("/hello")
	public String hello(Model model) {

		//message는 모델이름
		model.addAttribute("message","안녕하세요2");
		
		Map<String, Integer> map = new HashMap<>();
		map.put("11Pro", 139);
		map.put("ipad Pro", 102);
		map.put("watch", 53);
		model.addAttribute("map", map);

		/* 100=<x 귀족
		 * 50<=x<100 평민
		 * 20<=x<50 서민
		 * 20>x 거지
		 * th:if문으로 price 별 등급 */
		model.addAttribute("price",50); //폰 가격

		List<String> list = new ArrayList<>();
		list.add("김진영");
		list.add("김기태");
		list.add("김원진");
		model.addAttribute("list",list);
		
		Map<String, Integer> map2 = new HashMap<String, Integer>();
		map2.put("S10",20);
		map2.put("S10+",25);
		map2.put("Note10",40);
		model.addAttribute("map2",map2);
		
		//리스트 출력 형태 
		model.addAttribute("list2",Arrays.asList("ipad6","iphone8","mac"));
		
		//Customer dto 객체 불러오기 
		model.addAttribute("customer", new Customer(1,"GiJin","SEO"));
		
		return "hello";
	}
	
}
