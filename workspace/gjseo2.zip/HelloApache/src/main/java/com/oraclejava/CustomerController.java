package com.oraclejava;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomerController {
	
	//Customer
	@Autowired
	private CustomerRepository customerRepository;

	//cutomerRepository 에서 DB값을 가져와서 List에 넣어준다.
	@RequestMapping("/showCust")
	public String showCust(Model model) {
		List<Customer> list = customerRepository.findAll();
		model.addAttribute("list",list);
		
		return "cust";
	}
	
}
