package com.oraclejava;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/form")
public class FormController {

	@GetMapping //get방식으로 가져오겠다.
	public String show(Model model) {
		//model.addAttribute("myForm",new MyForm());
		model.addAttribute(new MyForm()); //위 코드를 생략한 형태  이름이 소문자대문자 비슷하면 생략 가능?
		
		return "showForm";
	}
	
	//전송 버튼을 누르면 넘어가는 페이지
//	@PostMapping
//	public String submit(MyForm form, Model model) {
//		System.out.println("name="+form.getName());
//		model.addAttribute("name",form.getName());
//		return "showFormSubmit";
//	}
	//나이까지 추가로 작업
	@PostMapping
	public String submit(MyForm form, Model model) {
		System.out.println("name,age="+form.getName()+form.getAge());
		model.addAttribute("name",form.getName());
		model.addAttribute("age",form.getAge());
		return "showFormSubmit";
	}
	
	
}
