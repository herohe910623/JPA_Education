package com.oraclejava;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NowController {

	private DateTimeFormatter formatter = 
			DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	
	//return 의 now는 now.html 을 가르키는 것이다?
	@RequestMapping("/now")
	public String now(Model model) {
		
		String time = formatter.format(LocalDateTime.now());
		model.addAttribute("currentTime", time);
		return "now";
	}
	
}
