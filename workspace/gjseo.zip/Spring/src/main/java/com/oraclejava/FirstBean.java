package com.oraclejava;

public class FirstBean {

	private String name;//이름
	private int age;//나이
	private boolean gender;//성별

	//Setter Injection 이라고 한다.
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	
	//toString 하기전에 check 먼저 실행 myMethod가 
	@Override
	public String toString() {
		return "FirstBean [이름=" + name + ", 나이=" + age + ", 성별=" + gender + "]";
	}



}
