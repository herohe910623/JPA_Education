package com.oraclejava;

public class SecondBean {
	private String name; //이름
	
	//Constructor Injection 
	public SecondBean(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "SecondBean [name=" + name + "]";
	}
	
	
}
