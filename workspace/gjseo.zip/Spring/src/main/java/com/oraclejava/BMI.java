package com.oraclejava;

public class BMI {

	private double height; //Ű
	private int weight; //������
	
	
	public void setHeight(double height) {
		this.height = height;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
//	public double getHeight() {
//		return height;
//	}
//	public int getWeight() {
//		return weight;
//	}
	@Override
	public String toString() {
		return "FirstBean [height=" + height + ", weight=" + weight + "]";
	}
	
	public void calc() {
		double bmi;
		double m_height = height * 0.01; // cm -> m
		bmi = weight / (m_height *m_height);
		System.out.println("BMI = " + bmi);
	}
	
}
