package com.oraclejava;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App3 {

	public static void main(String[] args) {
		ConfigurableApplicationContext 
		applicationContext = new AnnotationConfigApplicationContext(MyConfig.class);
		
		FirstBean firstBean = applicationContext.getBean("firstBean", FirstBean.class);
		BMI bmi = applicationContext.getBean("bmi", BMI.class);
		
		System.out.println(firstBean.toString());
		bmi.calc();
		applicationContext.close();
		
	}
}
