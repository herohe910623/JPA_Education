package com.oraclejava;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		//공장을 불러온다. xml파일을 불러온다
		ConfigurableApplicationContext applicationContext 
		= new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//타입까지 줘야한다.
		FirstBean firstBean = applicationContext.getBean("firstBean", FirstBean.class);
		System.out.println(firstBean.toString());
		//toString 이 생략되있다.
		
		//second get bean
		SecondBean secondBean = applicationContext.getBean("secondBean", SecondBean.class);
		System.out.println(secondBean);
		applicationContext.close();
		
	}

}
