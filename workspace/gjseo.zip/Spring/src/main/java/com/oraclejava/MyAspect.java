package com.oraclejava;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {
	
	//포인트컷으로 잡는다. 실행시켜주는것은  to string으로 잡앗다.
	@Pointcut("execution(* toString(..))")
	private void myMethod() {
		
	}
	
	//before 어드바이스 사전에 
	@Before("myMethod()")
	public void check() {
		System.out.println("check!");
	}
	
//	@AfterReturning("myMethod()")
//	public void confirm() {
//		System.out.println("confirm!");
//	}
	
	@AfterReturning(pointcut ="myMethod()", returning = "retVal1")
	public void confirm(Object retVal1) {
		System.out.println("confirm!");
		System.out.println(retVal1.toString());
	}
}
