package com.oraclejava;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@EnableAspectJAutoProxy //AOP 유효화 이게없으면 동작을 안함 
//properties 파일 불러오기
@PropertySource("classpath:spring.properties") //properties source bean을 하나 줘야한다.
public class MyConfig {

	//메서드가 firstBean
	//빈은 Bean 
	//클래스는 Configuration

	@Bean
	public FirstBean firstBean() {
		FirstBean bean = new FirstBean();
		bean.setName("서기진");
		bean.setAge(30);
		bean.setGender(false);
		return bean;
		//무조건 빈 리턴
	}
	//AOP 
	@Bean
	public MyAspect myAspect() {
		return new MyAspect();
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}


	@Value("${spring.height}")
	private double height;

	@Value("${spring.weight}")
	private double weight;

	@Bean
	public BMI bmi() {
		BMI bean = new BMI();
		bean.setHeight(190);
		bean.setWeight(80);
		return bean;
	}
}

